# 06_Krzywe_Stozkowe
