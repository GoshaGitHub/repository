# 03_Wektory_definicje
