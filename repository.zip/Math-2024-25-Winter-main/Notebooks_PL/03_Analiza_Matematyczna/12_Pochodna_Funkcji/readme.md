# 12_Pochodna_Funkcji
