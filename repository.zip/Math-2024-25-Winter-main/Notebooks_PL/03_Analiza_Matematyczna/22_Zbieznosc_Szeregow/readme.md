# 22_Zbieznosc_Szeregow
