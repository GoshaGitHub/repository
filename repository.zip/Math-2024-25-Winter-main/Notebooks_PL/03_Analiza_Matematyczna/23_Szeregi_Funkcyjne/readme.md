# 23_Szeregi_Funkcyjne
