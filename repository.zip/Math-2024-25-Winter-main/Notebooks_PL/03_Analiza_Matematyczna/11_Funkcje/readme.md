# 11_Funkcje
