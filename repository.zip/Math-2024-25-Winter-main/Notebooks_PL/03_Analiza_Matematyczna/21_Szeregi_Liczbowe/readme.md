# 21_Szeregi_Liczbowe
