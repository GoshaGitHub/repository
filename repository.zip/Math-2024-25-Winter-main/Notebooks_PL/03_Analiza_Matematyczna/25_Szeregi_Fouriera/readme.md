# 25_Szeregi_Fouriera
